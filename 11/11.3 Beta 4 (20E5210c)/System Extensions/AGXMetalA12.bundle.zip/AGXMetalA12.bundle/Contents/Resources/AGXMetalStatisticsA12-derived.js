
// input: num_cores - the number of FSTP cores.;
// input: num_gps - the number of GTP GPs.;
// we default initialize the inputs so that generate_derived_ctr_plists.py does not deduce that they are counters
var num_cores = 4;
var num_gps = 2;
var MAX_SGID_PER_USC = 768;
var NUM_THREADS_PER_CLIQUE = 32;
var TileWidth = 0;
var TileHeight = 0;

// name: GPU Time
// description: GPU Time in nSec
// type: Count
function GPUTime()
{
    return MTLStat_nSec;
}

// name: Vertex Pipeline %
// description: % of vertex processing
// type: Percentage
function VertexPipelinePercent()
{
    return (MTLStatTotalGPUCycles_vtx * 100) / (MTLStatTotalGPUCycles_frg + MTLStatTotalGPUCycles_vtx);    
}

// name: Fragment Pipeline %
// description: % of fragment processing
// type: Percentage
function FragmentPipelinePercent()
{
    return (MTLStatTotalGPUCycles_frg * 100) / (MTLStatTotalGPUCycles_frg + MTLStatTotalGPUCycles_vtx);
}

// name: Shader Core Vertex Utilization %
// description: % Shader Core Vertex Utilization
// type: Percentage
function ShaderCoreVertexUtilization()
{
    return USC1_VDM_SGID_COUNT_norm_vtx / (MAX_SGID_PER_USC * num_cores);
}

// name: Shader Core Fragment Utilization %
// description: % Shader Core Fragment Utilization
// type: Percentage
function ShaderCoreFragmentUtilization()
{
    return USC1_PDM_SGID_COUNT_norm_frg / (MAX_SGID_PER_USC * num_cores);
}

// name: Shader Core Compute Utilization %
// description: % Shader Core Compute Utilization
// type: Percentage
function ShaderCoreComputeUtilization()
{
    return USC1_CDM_SGID_COUNT_norm / (MAX_SGID_PER_USC * num_cores);
}

// name: VS ALU Instructions
// description: VS ALU Instructions
// type: Count
function VSALUInstructions()
{ 
    return (NUM_THREADS_PER_CLIQUE / 2) * USC0_DPIL0_DPB_INSTR_WORK_vtx * 4;
}

// name: VS ALU FP32 Instructions %
// description: VS ALU FP32 Instructions
// type: Percentage
function VSALUF32Percent()
{
    return 100 * (USC0_DPB_NUM_THR_F32_OPS_vtx * 16) / VSALUInstructions();
}

// name: VS ALU FP16 Instructions %
// description: VS ALU FP16 Instructions
// type: Percentage
function VSALUF16Percent()
{
    return 100 * (USC0_DPB_NUM_THR_F16_OPS_vtx * 16) / VSALUInstructions();
}

// name: VS ALU 32-bit Integer and Conditional Instructions %
// description: VS ALU Select, Conditional, 32-bit Integer and Boolean Instructions
// type: Percentage
function VSALUInt32AndCondPercent()
{
    return 100 * (USC0_DPB_NUM_THR_SCIB_OPS_vtx * 16) / VSALUInstructions();
}

// name: VS ALU Integer and Complex Instructions %
// description: VS ALU Integer and Complex Instructions
// type: Percentage
function VSALUIntAndComplexPercent()
{
    return 100 * (USC0_DPB_NUM_THR_IC_OPS_vtx * 16) / VSALUInstructions();
}

// name: FS ALU Instructions
// description: FS ALU Instructions
// type: Count
function FSALUInstructions()
{
    return (NUM_THREADS_PER_CLIQUE / 2) * USC0_DPIL0_DPB_INSTR_WORK_frg * 4;
}

// name: FS ALU FP32 Instructions %
// description: FS ALU FP32 Instructions
// type: Percentage
function FSALUF32Percent()
{
    return 100 * (USC0_DPB_NUM_THR_F32_OPS_frg * 16) / FSALUInstructions();
}

// name: FS ALU FP16 Instructions %
// description: FS ALU FP16 Instructions
// type: Percentage
function FSALUF16Percent()
{
    return 100 * (USC0_DPB_NUM_THR_F16_OPS_frg * 16) / FSALUInstructions();
}

// name: FS ALU 32-bit Integer and Conditional Instructions %
// description: FS ALU Select, Conditional, 32-bit Integer and Boolean Instructions
// type: Percentage
function FSALUInt32AndCondPercent()
{
    return 100 * (USC0_DPB_NUM_THR_SCIB_OPS_frg * 16) / FSALUInstructions();
}

// name: FS ALU Integer and Complex Instructions %
// description: FS ALU Integer and Complex Instructions
// type: Percentage
function FSALUIntAndComplexPercent()
{
    return 100 * (USC0_DPB_NUM_THR_IC_OPS_frg * 16) / FSALUInstructions();
}

// name: CS ALU Instructions
// description: CS ALU Instructions
// type: Count
function CSALUInstructions()
{
    return (NUM_THREADS_PER_CLIQUE / 2) * USC0_DPIL0_DPB_INSTR_WORK_cmp * 4;
}

// name: CS ALU FP32 Instructions %
// description: CS ALU FP32 Instructions
// type: Percentage
function CSALUF32Percent()
{
    return 100 * (USC0_DPB_NUM_THR_F32_OPS_cmp * 16) / CSALUInstructions();
}

// name: CS ALU FP16 Instructions %
// description: CS ALU FP16 Instructions
// type: Percentage
function CSALUF16Percent()
{
    return 100 * (USC0_DPB_NUM_THR_F16_OPS_cmp * 16) / CSALUInstructions();
}

// name: CS ALU 32-bit Integer and Conditional Instructions %
// description: CS ALU Select, Conditional, 32-bit Integer and Boolean Instructions
// type: Percentage
function CSALUInt32AndCondPercent()
{
    return 100 * (USC0_DPB_NUM_THR_SCIB_OPS_cmp * 16) / CSALUInstructions();
}

// name: CS ALU Integer and Complex Instructions %
// description: CS ALU Integer and Complex Instructions
// type: Percentage
function CSALUIntAndComplexPercent()
{
    return 100 * (USC0_DPB_NUM_THR_IC_OPS_cmp * 16) / CSALUInstructions();
}

// name: VS Invocations
// description: Number of times vertex shader is invoked
// type: Count
function VSInvocation()
{
    return GTP_GP_PERF_VDM_VS_INVOCATION_vtx;
}

// name: FS Invocations
// description: Number of times fragment shader is invoked
// type: Count
function PSInvocation()
{
    return FRG0_PIXELS_ITB_POST_TS * 32;
}

// name: CS Invocations
// description: Number of times compute shader is invoked
// type: Count
function CSInvocation()
{
    return GTP_CORE_PERF_GTP_CDM_WI_SENT_STP0 + GTP_CORE_PERF_GTP_CDM_WI_SENT_STP1 + GTP_CORE_PERF_GTP_CDM_WI_SENT_STP2 + GTP_CORE_PERF_GTP_CDM_WI_SENT_STP3;           
}

// name: Vertex Rate
// description: Number of vertices processed per nanosecond
// type: Rate
function VerticesPerNSec()
{
    return VSInvocation() / (GBL_GPU_N_CLK_TIMER_vtx * 41.666);
}

// name: Primitive Rate
// description: Number of primitives processed per nanosecond
// type: Rate
function PrimitivesPerNSec()
{
    return PrimitivesSubmitted() / (GBL_GPU_N_CLK_TIMER_vtx * 41.666);
}

// name: Pixel Rate
// description: Number of fragments processed per nanosecond
// type: Rate
function PixelsPerNSec()
{
    return PSInvocation() / (GBL_GPU_N_CLK_TIMER_frg * 41.666);
}

// name: Pixel To Vertex Ratio
// description: Number of pixels per vertex
// type: Rate
function PixelToVertexRatio()
{
    return PSInvocation() / VSInvocation();
}

// name: Pixel Per Triangle
// description: Number of pixels per triangle
// type: Rate
function PixelPerTriangle()
{
    return PSInvocation() / PrimitivesSubmitted();
}

// name: Draw Calls
// description: Number of draw calls
// type: Count
function DrawCalls()
{
    return GTP_GP_PERF_VDM_BATCH_CHANGE_vtx / num_gps;
}

// name: Vertex Count
// description: Number of vertices being submitted to input assembly
// type: Count
function VerticesSubmitted()
{
    return GTP_GP_PERF_VDM_VERTEX_FETCH_vtx;
}

// name: Vertices Reused
// description: Number of vertices being reused
// type: Count
function VerticesReused()
{
    return VerticesSubmitted() - VSInvocation();
}

// name: Vertices Reused %
// description: % of vertices being reused
// type: Percentage
function VerticesReusedPercent()
{
    return (VerticesSubmitted() - VSInvocation()) * 100 / VerticesSubmitted();
}

// name: Primitives Submitted
// description: Number of primitives gathered by input assembly
// type: Count
function PrimitivesSubmitted()
{
    return GTP_GP_PERF_VDM_PRIM_FETCH_vtx;
}

// name: Primitives Rasterized
// description: Number of primitives rasterized
// type: Count
function PrimitivesRasterized()
{
    return GTP_CORE_PERF_TA_VCE_PRIM_OUTPUT_vtx;
}

// name: Primitives Rendered %
// description: % of primitives rasterized
// type: Percentage
function PrimitivesRasterizedPercent()
{
    return PrimitivesRasterized() * 100 / PrimitivesSubmitted();
}

// name: Primitives Clipped
// description: Number of primitives being clipped
// type: Count
function ClippedPrimitives()
{
    return GTP_GP_PERF_TA_CLIP_LINE_vtx + GTP_GP_PERF_TA_CLIP_TRI_vtx;
}

// name: Primitives Clipped %
// description: % of primitives clipped
// type: Percentage
function ClippedPrimitivesPercent()
{
    return ClippedPrimitives() * 100 / PrimitivesSubmitted();
}

// name: Back-Facing/Zero Area Cull Primitives
// description: Number of primitives being culled due to being back-facing or having zero area coverage
// type: Count
function BackFaceZeroAreaCullPrims()
{
    return GTP_GP_PERF_TA_PPP_CULL_TRI_BACK_vtx + GTP_CORE_PERF_TA_VCE_CULL_TRI_SMALL_vtx;
}

// name: Back-Facing/Zero Area Cull Primitives %
// description: % of primitives being culled due to being back-facing or having zero area coverage
// type: Percentage
function BackFaceZeroAreaCullPrimsPercent()
{
    return (BackFaceZeroAreaCullPrims() * 100) / PrimitivesSubmitted();
}

// name: Guard Band Cull Primitives
// description: Number of primitives being culled due to being outside guard band
// type: Count
function GuardBandCullPrims()
{
    return GTP_GP_PERF_TA_PPP_CULL_LINE_FULL_vtx + GTP_GP_PERF_TA_PPP_CULL_POINT_FULL_vtx + GTP_GP_PERF_TA_PPP_CULL_TRI_FULL_vtx;
}

// name: Guard Band Cull Primitives %
// description: % of primitives being culled due to being outside guard band
// type: Percentage
function GuardBandCullPrimsPercent()
{
    return GuardBandCullPrims() * 100 / PrimitivesSubmitted();
}

// name: Off-screen Cull Primitives
// description: Number of primitives being culled due to being off-screen
// type: Count
function OffscreenCullPrims()
{
    return GTP_GP_PERF_TA_PPP_CULL_LINE_OFF_vtx + GTP_GP_PERF_TA_PPP_CULL_POINT_OFF_vtx + GTP_GP_PERF_TA_PPP_CULL_TRI_OFF_vtx;
}

// name: Off-screen Cull Primitives %
// description: % of primitives being culled due to being off-screen
// type: Percentage
function OffscreenCullPrimsPercent()
{
    return OffscreenCullPrims() * 100 / PrimitivesSubmitted();
}

// name: Fragments Rasterized
// description: Number of fragments rasterized
// type: Count
function FragmentsRasterized()
{
    return FRG0_PIXELS_ITB_POST_DS * 32;
}

// name: Pre Z Pass Count
// description: Pre Z Pass Count
// type: Count
function PreZPassCount()
{
    return FRG0_PIXELS_ITB_POST_DS * 32;
}

// name: Pre Z Fail Count
// description: Pre Z Fail Count
// type: Count
function PreZFailCount()
{
    return Math.max(FragmentsRasterized() - PreZPassCount(), 0.0);
}

// name: Pre Z Fail %
// description: % Pre Z Fail
// type: Percentage
function PreZFailCountPercent()
{
    return PreZFailCount() * 100 / FragmentsRasterized();
}

// name: Pre Z Pass %
// description: % Pre Z Pass
// type: Percentage
function PreZPassCountPercent()
{
    return (PreZPassCount() * 100) / FragmentsRasterized();
}

// name: Pixels Per Tile
// description: Pixels per tile
// type: Count
function PixelsPerTile()
{
    return TileWidth * TileHeight;
}

// name: Average Overdraw
// description: Pixel Overdraw
// type: Count
function AverageOverdraw()
{
    if (TileWidth * TileHeight > 0)
    {
        return PSInvocation() / (FRG0_STAT_PF_VALID_TILES_PROCESSED * TileWidth * TileHeight);
    }
    return 0;
}

// name: VS Texture Cache Miss Rate
// description: Percentage of time L1 Texture Cache access is a Miss
// type: Percentage
function VSTextureCacheMissRate()
{
    return TPU_TL1C_TOP_GM_REQUEST_vtx * 100 / (4.0 * TPU_TL1C_TOP_REQUEST4_VALID_ADDRESS_vtx + 3.0 * TPU_TL1C_TOP_REQUEST3_VALID_ADDRESS_vtx + 2.0 * TPU_TL1C_TOP_REQUEST2_VALID_ADDRESS_vtx + TPU_TL1C_TOP_REQUEST1_VALID_ADDRESS_vtx)
}

// name: FS Texture Cache Miss Rate
// description: Percentage of time L1 Texture Cache access is a Miss
// type: Percentage
function FSTextureCacheMissRate()
{
    return TPU_TL1C_TOP_GM_REQUEST_frg  * 100 / (4.0 * TPU_TL1C_TOP_REQUEST4_VALID_ADDRESS_frg + 3.0 * TPU_TL1C_TOP_REQUEST3_VALID_ADDRESS_frg + 2.0 * TPU_TL1C_TOP_REQUEST2_VALID_ADDRESS_frg + TPU_TL1C_TOP_REQUEST1_VALID_ADDRESS_frg)
}

// name: VS USC L1 Cache Requests
// description: VS L1 Requests
// type: Count
function VSBufferL1Requests()
{
  return USC_L1C_BANK0_HALF0_LOAD_REQUEST_vtx + 
         USC_L1C_BANK0_HALF1_LOAD_REQUEST_vtx + 
         USC_L1C_BANK1_HALF0_LOAD_REQUEST_vtx + 
         USC_L1C_BANK1_HALF1_LOAD_REQUEST_vtx + 
         USC_L1C_BANK0_HALF0_STORE_REQUEST_vtx + 
         USC_L1C_BANK0_HALF1_STORE_REQUEST_vtx + 
         USC_L1C_BANK1_HALF0_STORE_REQUEST_vtx + 
         USC_L1C_BANK1_HALF1_STORE_REQUEST_vtx;
}

// name: VS USC L1 Cache Hits
// description: VS L1 Request Hits
// type: Count
function VSBufferL1RequestHits()
{
  return USC_L1C_BANK0_HALF0_LOAD_REQUEST_HIT_vtx + 
         USC_L1C_BANK0_HALF1_LOAD_REQUEST_HIT_vtx + 
         USC_L1C_BANK1_HALF0_LOAD_REQUEST_HIT_vtx + 
         USC_L1C_BANK1_HALF1_LOAD_REQUEST_HIT_vtx + 
         USC_L1C_BANK0_HALF0_STORE_REQUEST_HIT_vtx + 
         USC_L1C_BANK0_HALF1_STORE_REQUEST_HIT_vtx + 
         USC_L1C_BANK1_HALF0_STORE_REQUEST_HIT_vtx + 
         USC_L1C_BANK1_HALF1_STORE_REQUEST_HIT_vtx;
}

// name: VS USC L1 Cache Miss Rate
// description: Percentage of time VS USC L1 Requests are misses
// type: Percentage
function VSBufferL1RequestMissRate()
{
  var uscL1Requests = VSBufferL1Requests();
  return 100.0 * Math.max(uscL1Requests - VSBufferL1RequestHits(), 0.0) / Math.max(uscL1Requests, 1.0);
}

// name: FS USC L1 Cache Requests
// description: FS L1 Request
// type: Count
function FSBufferL1Requests()
{
  return USC_L1C_BANK0_HALF0_LOAD_REQUEST_frg + 
         USC_L1C_BANK0_HALF1_LOAD_REQUEST_frg + 
         USC_L1C_BANK1_HALF0_LOAD_REQUEST_frg + 
         USC_L1C_BANK1_HALF1_LOAD_REQUEST_frg + 
         USC_L1C_BANK0_HALF0_STORE_REQUEST_frg + 
         USC_L1C_BANK0_HALF1_STORE_REQUEST_frg + 
         USC_L1C_BANK1_HALF0_STORE_REQUEST_frg + 
         USC_L1C_BANK1_HALF1_STORE_REQUEST_frg;
}

// name: FS USC L1 Cache Hits
// description: FS L1 Request Hits
// type: Count
function FSBufferL1RequestHits()
{
  return USC_L1C_BANK0_HALF0_LOAD_REQUEST_HIT_frg + 
         USC_L1C_BANK0_HALF1_LOAD_REQUEST_HIT_frg + 
         USC_L1C_BANK1_HALF0_LOAD_REQUEST_HIT_frg + 
         USC_L1C_BANK1_HALF1_LOAD_REQUEST_HIT_frg + 
         USC_L1C_BANK0_HALF0_STORE_REQUEST_HIT_frg + 
         USC_L1C_BANK0_HALF1_STORE_REQUEST_HIT_frg + 
         USC_L1C_BANK1_HALF0_STORE_REQUEST_HIT_frg + 
         USC_L1C_BANK1_HALF1_STORE_REQUEST_HIT_frg;
}

// name: FS USC L1 Cache Miss Rate
// description: Percentage of time VS USC L1 Requests are misses
// type: Percentage
function FSBufferL1RequestMissRate()
{
  var uscL1Requests = FSBufferL1Requests();
  return 100.0 * Math.max(uscL1Requests - FSBufferL1RequestHits(), 0.0) / Math.max(uscL1Requests, 1.0);
}

// name: USC L1 Cache Requests
// description: L1 Requests
// type: Count
function BufferL1Requests()
{
  return USC_L1C_BANK0_HALF0_LOAD_REQUEST + 
         USC_L1C_BANK0_HALF1_LOAD_REQUEST + 
         USC_L1C_BANK1_HALF0_LOAD_REQUEST + 
         USC_L1C_BANK1_HALF1_LOAD_REQUEST + 
         USC_L1C_BANK0_HALF0_STORE_REQUEST + 
         USC_L1C_BANK0_HALF1_STORE_REQUEST + 
         USC_L1C_BANK1_HALF0_STORE_REQUEST + 
         USC_L1C_BANK1_HALF1_STORE_REQUEST;
}

// name: USC L1 Cache Hits
// description: L1 Request Hits
// type: Count
function BufferL1RequestHits()
{
  return USC_L1C_BANK0_HALF0_LOAD_REQUEST_HIT + 
         USC_L1C_BANK0_HALF1_LOAD_REQUEST_HIT + 
         USC_L1C_BANK1_HALF0_LOAD_REQUEST_HIT + 
         USC_L1C_BANK1_HALF1_LOAD_REQUEST_HIT + 
         USC_L1C_BANK0_HALF0_STORE_REQUEST_HIT + 
         USC_L1C_BANK0_HALF1_STORE_REQUEST_HIT + 
         USC_L1C_BANK1_HALF0_STORE_REQUEST_HIT + 
         USC_L1C_BANK1_HALF1_STORE_REQUEST_HIT;
}

// name: USC L1 Cache Miss Rate
// description: Percentage of time USC L1 Requests are misses
// type: Percentage
function BufferL1RequestMissRate()
{
  var uscL1Requests = BufferL1Requests();
  return 100.0 * Math.max(uscL1Requests - BufferL1RequestHits(), 0.0) / Math.max(uscL1Requests, 1.0);
}

// name: VS Texture samples
// description: VS Texture samples
// type: Count
function VSTextureSamples()
{
    return TPU_EVENT_NUM_PIXELS_vtx * 64
}

// name: FS Texture samples
// description: FS Texture samples
// type: Count
function FSTextureSamples()
{
   return TPU_EVENT_NUM_PIXELS_frg * 64
}

// name: CS Texture samples
// description: CS Texture samples
// type: Count
function CSTextureSamples()
{
   return TPU_EVENT_NUM_PIXELS_cmp * 64
}

// name: Texture samples per invocation
// description: VS Texture samples per invocation
// type: Rate
function VSTextureSamplesPerInvocation()
{
    return VSTextureSamples() / VSInvocation()
}

// name: Texture samples per invocation
// description: FS Texture samples per invocation
// type: Rate
function FSTextureSamplesPerInvocation()
{
    return FSTextureSamples() / PSInvocation()
}

// name: Texture samples per invocation
// description: CS Texture samples per invocation
// type: Rate
function CSTextureSamplesPerInvocation()
{
    return CSTextureSamples() / CSInvocation()
}

// name: Average Anisotropic Ratio
// description: Average Anisotropic Ratio
// type: Rate
function AverageAnisotropicRatio()
{
    var total = TPU_EVENT_ANISO_1X +
                2 * TPU_EVENT_ANISO_2X +
                3 * TPU_EVENT_ANISO_3X +
                4 * TPU_EVENT_ANISO_4X +
                6 * TPU_EVENT_ANISO_6X +
                8 * TPU_EVENT_ANISO_8X +
                10 * TPU_EVENT_ANISO_10X +
                12 * TPU_EVENT_ANISO_12X +
                14 * TPU_EVENT_ANISO_14X +
                16 * TPU_EVENT_ANISO_16X;
        
    return Math.round(total / TPU_EVENT_ANISO_EN);
}

// name: Total Texture Samples
// description: Total Number of texture samples
// type: Count
function TextureSamples()
{
    return TPU_EVENT_NUM_PIXELS * 64;
}

// name: Anisotropic Samples
// description: Number of texture samples with anisotropic filtering
// type: Count
function AnisotropicSamples()
{
    return TPU_EVENT_ANISO_EN * 4;
}

// name: Anisotropic Samples %
// description: % of texture samples with anisotropic filtering
// type: Percentage
function AnisotropicSamplesPercent()
{
    return (TPU_EVENT_ANISO_EN * 100) / (TPU_EVENT_NUM_QUADS * 64);
}

// name: Mipmap Linear Samples
// description: Number of texture samples with linear mipmap filter
// type: Count
function MipmapLinearSamples()
{
    return TPU_EVENT_MIP_LINEAR * 4;
}

// name: Mipmap Linear Samples %
// description: % of texture samples with linear mipmap filter
// type: Percentage
function MipmapLinearSamplesPercent()
{
    return (TPU_EVENT_MIP_LINEAR * 100) / (TPU_EVENT_NUM_QUADS * 64);
}

// name: Mipmap Nearest Samples
// description: Number of texture samples with nearest mipmap filter
// type: Count
function MipmapNearestSamples()
{
    return TPU_EVENT_MIP_NEAREST * 4;
}

// name: Mipmap Nearest Samples %
// description: % of texture samples with nearest mipmap filter
// type: Percentage
function MipmapNearestSamplesPercent()
{
    return (TPU_EVENT_MIP_NEAREST * 100) / (TPU_EVENT_NUM_QUADS * 64);
}

// name: Compressed Texture Samples
// description: Number of compressed texture samples
// type: Count
function CompressedSamples()
{
    var CompressedSamples = TPU_EVENT_FMT_PVRTC_2 +
                            TPU_EVENT_FMT_PVRTC_4 +
                            TPU_EVENT_FMT_ETC2 +
                            TPU_EVENT_FMT_ETC2_EAC +
                            TPU_EVENT_FMT_PUNCHTHROUGH_ALPHA1_ETC2 +
                            TPU_EVENT_FMT_R11_EAC +
                            TPU_EVENT_FMT_RG11_EAC +
                            TPU_EVENT_FMT_ASTC_LOW_BPP +                            
                            TPU_EVENT_FMT_ASTC_HIGH_BPP +
                            TPU_EVENT_FMT_ASTC_4X2 +
                            TPU_EVENT_FMT_ASTC_4X4 +
                            TPU_EVENT_FMT_ASTC_8X4 +
                            TPU_EVENT_FMT_ASTC_8X8 +
                            TPU_EVENT_FMT_ASTC_12X12;

    return CompressedSamples * 4;
}

// name: Compressed Samples %
// description: Percentage of samples to compressed textures
// type: Percentage
function CompressedSamplesPercent()
{
    return Math.min((CompressedSamples() * 100.0) / Math.max(TextureSamples(), 1.0), 100.0);
}

// name: Lossless Compressed Texture Samples
// description: Number of lossless compressed texture samples
// type: Count
function LosslessCompressedSamples()
{
    return TPU_EVENT_COMPRESSED_LOSSLESS * 4;
}

// name: Lossless Compressed Samples %
// description: Percentage of samples to compressed textures
// type: Percentage
function LosslessCompressedSamplesPercent()
{
    return Math.min((LosslessCompressedSamples() * 100.0) / Math.max(TextureSamples(), 1.0), 100.0);
}

// name: Uncompressed Texture Samples
// description: Number of uncompressed texture samples
// type: Count
function UncompressedSamples()
{
    return Math.max(TextureSamples() - (CompressedSamples() + LosslessCompressedSamples()), 0);
}

// name: Uncompressed Samples %
// description: Percentage of samples to compressed textures
// type: Percentage
function UnCompressedSamplesPercent()
{
    return Math.min(100.0 * UncompressedSamples() / Math.max(TextureSamples(), 1.0), 100.0);
}

// name: Pixels Written to Memory Unbiased
// description: Number of pixels unbiased written to memory
// type: Count
function PixelsUnbiasedWrittenToMemory()
{
    return PBE_NUM_PIXELS * 4;
}    

// name: Texture Pixels Written to Memory by Pixel Write Instructions
// description: Number of texture pixels written to memory
// type: Count
function TexturePixelsWrittenToMemory()
{
    return PBE_NUM_PIXEL_WRITES * 4;
}

// name: Pixels Written to Memory
// description: Number of pixels written to memory
// type: Count
function PixelsWrittenToMemory()
{
    return Math.max(PixelsUnbiasedWrittenToMemory(), TexturePixelsWrittenToMemory());
}

// name: Attachment Pixels Written to Memory
// description: Number of pixels written to memory
// type: Count
function AttachmentPixelsWrittenToMemory()
{
    return Math.max(PixelsUnbiasedWrittenToMemory() - TexturePixelsWrittenToMemory(), 0.0);
}

// name: Compressed Pixels Written to Memory
// description: Number of compressed pixels written to memory
// type: Count
function CompressedPixelsWrittenToMemory()
{
    return PBE_COMPRESS_LOSSLESS * 4;
}

// name: Percentage of Texture Pixels Written to Memory by Pixel Write Instructions
// description: Number of texture pixels written to memory
// type: Percentage
function TexturePixelsWrittenToMemoryPercent()
{
    return 100.0 * TexturePixelsWrittenToMemory() / Math.max(PixelsWrittenToMemory(), 1.0);
}

// name: Percentage of Attachment Pixels Written to Memory
// description: Percentage of number of attachment pixels written to memory
// type: Percentage
function AttachmentPixelsWrittenToMemoryPercent()
{
    return 100.0 * AttachmentPixelsWrittenToMemory() / Math.max(PixelsWrittenToMemory(), 1.0);
}

// name: Percentage of Compressed Pixels Written to Memory
// description: Percentage of number of compressed pixels written to memory
// type: Percentage
function CompressedPixelsWrittenToMemoryPercent()
{
    return 100.0 * CompressedPixelsWrittenToMemory() / Math.max(PixelsWrittenToMemory(), 1.0);
}

// name: Number of 2xMSAA Resolved Pixels
// description: Number of 2xMSAA resolved pixels
// type: Count
function MSAA2XResolvedPixels()
{
    return PBE_RESOLVE_2X * 4;
}

// name: Number of 4xMSAA Resolved Pixels
// description: Number of 4xMSAA resolved pixels
// type: Count
function MSAA4XResolvedPixels()
{
    return PBE_RESOLVE_4X * 4;
}

// name: Number of 2xMSAA Resolved Pixels
// description: Number of 2xMSAA resolved pixels
// type: Percentage
function MSAA2XResolvedPixelsPercent()
{
    return 100.0 * (MSAA2XResolvedPixels() / Math.max(PixelsWrittenToMemory(), 1.0));
}

// name: Number of 4xMSAA Resolved Pixels
// description: Number of 4xMSAA resolved pixels
// type: Percentage
function MSAA4XResolvedPixelsPercent()
{
    return 100.0 * (MSAA4XResolvedPixels() / Math.max(PixelsWrittenToMemory(), 1.0));
}


// name: Number of Total Resolved Pixels
// description: Number of total resolved pixels
// type: Count
function TotalResolvedPixels()
{
    return (PBE_RESOLVE_NUM_1FRAG_PIXELS + PBE_RESOLVE_NUM_2FRAG_PIXELS + PBE_RESOLVE_NUM_3FRAG_PIXELS + PBE_RESOLVE_NUM_4FRAG_PIXELS) * 4.0;
}

// name: Average Unique Colors Per Resolved Pixels
// description: Average unique colors per resolved pixels
// type: Rate
function AverageUniqueColorsPerResolvedPixels()
{    
    return 4.0 * (PBE_RESOLVE_NUM_1FRAG_PIXELS + 2.0*PBE_RESOLVE_NUM_2FRAG_PIXELS + 3.0*PBE_RESOLVE_NUM_3FRAG_PIXELS + 4.0*PBE_RESOLVE_NUM_4FRAG_PIXELS) / Math.max(TotalResolvedPixels(), 1.0);
}

// name: Texture Sample Limiter
// description: Measures the time during which texture samples are attempted to execute as a percentage of peak texture sample performance.
// type: Percentage
function TPULimiter()
{
    return TPU_LIMITER_norm / (2.0 * num_cores);
}

// name: Vertex Texture Sample Limiter
// description: Vertex texture sample limiter
// type: Percentage
function VertexTPULimiter()
{    
    return TPU_LIMITER_norm_vtx / (2.0 * num_cores);
}   

// name: Fragment Texture Sample Limiter
// description: Fragment texture sample limiter
// type: Percentage
function FragmentTPULimiter()
{
    return TPU_LIMITER_norm_frg / (2.0 * num_cores);
}   

// name: ALU Limiter
// description: Measures the time during which ALU work is attempted to execute as a percentage of peak ALU performance.
// type: Percentage
function ALULimiter()
{    
    return (USC0_DPIL0_DPB_INSTR_WORK_norm + USC0_DPIL0_DPB_INSTR_STALLED_norm) / (2 * num_cores);
}

// name: Vertex ALU Limiter
// description: Vertex ALU Limiter
// type: Percentage
function VertexALULimiter()
{
    return (USC0_DPIL0_DPB_INSTR_WORK_norm_vtx + USC0_DPIL0_DPB_INSTR_STALLED_norm_vtx) / (2 * num_cores);
}

// name: Fragment ALU Limiter
// description: Fragment ALU Limiter
// type: Percentage
function FragmentALULimiter()
{
    return (USC0_DPIL0_DPB_INSTR_WORK_norm_frg + USC0_DPIL0_DPB_INSTR_STALLED_norm_frg) / (2 * num_cores);
}

// name: Texture Write Limiter
// description: Measures the time during which texture writes are attempted to execute as a percentage of peak texture write performance.
// type: Percentage
function PBELimiter()
{
    return (PBE_USC_PBE_DATA_WORK_norm + PBE_USC_PBE_DATA_STALL_norm) / num_cores;
}

// name: VS Texture Write Limiter
// description: VS Texture write limiter
// type: Percentage
function VertexPBELimiter()
{
    return (PBE_USC_PBE_DATA_WORK_norm_vtx + PBE_USC_PBE_DATA_STALL_norm_vtx) / num_cores;
}

// name: FS Texture Write Limiter
// description: FS Texture write limiter
// type: Percentage
function FragmentPBELimiter()
{
    return (PBE_USC_PBE_DATA_WORK_norm_frg + PBE_USC_PBE_DATA_STALL_norm_frg) / num_cores;
}

// name: Sample Limiter
// description: % Sample Limiter
// type: Percentage
function SampleLimiter()
{
    return (USC0_SMP_COORD_WORK_norm + USC0_SMP_COORD_STALLED_norm) * 0.5 / num_cores;
}

// name: VS Sample Limiter
// description: % VS Sample Limiter
// type: Percentage
function VertexSampleLimiter()
{
    return (USC0_SMP_COORD_WORK_norm_vtx + USC0_SMP_COORD_STALLED_norm_vtx) * 0.5 / num_cores;
}

// name: FS Sample Limiter
// description: % FS Sample Limiter
// type: Percentage
function FragmentSampleLimiter()
{
    return (USC0_SMP_COORD_WORK_norm_frg + USC0_SMP_COORD_STALLED_norm_frg) * 0.5 / num_cores;
}

// name: Threadgroup/Imageblock Load Limiter
// description: Measures the time during which threadgroup and imageblock threadgroup loads are attempted to execute as a percentage of peak threadgroup and imageblock threadgroup performance.
// type: Percentage
function LocalLoadLimiter()
{
    return USC0_LLD_LIMITER_norm / (4.0 * num_cores);
}

// name: VS Threadgroup/Imageblock Load Limiter
// description: VS Threadgroup/Imageblock load limiter
// type: Percentage
function VertexLocalLoadLimiter()
{
    return USC0_LLD_LIMITER_norm_vtx / (4.0 * num_cores);
}

// name: FS Threadgroup/Imageblock Load Limiter
// description: FS Threadgroup/Imageblock load limiter
// type: Percentage
function FragmentLocalLoadLimiter()
{
    return USC0_LLD_LIMITER_norm_frg / (4.0 * num_cores);
}

// name: Threadgroup/Imageblock Store Limiter
// description: Measures the time during which threadgroup and imageblock threadgroup stores are attempted to execute as a percentage of peak threadgroup and imageblock threadgroup performance.
// type: Percentage
function LocalStoreLimiter()
{
    return USC0_LST_LIMITER_norm / (4.0 * num_cores);
}

// name: VS Threadgroup/Imageblock Store Limiter
// description: VS Threadgroup/Imageblock store limiter
// type: Percentage
function VertexLocalStoreLimiter()
{
    return USC0_LST_LIMITER_norm_vtx / (4.0 * num_cores);
}

// name: FS Threadgroup/Imageblock Store Limiter
// description: FS Threadgroup/Imageblock store limiter
// type: Percentage
function FragmentLocalStoreLimiter()
{
    return USC0_LST_LIMITER_norm_frg / (4.0 * num_cores);
}

// name: Texture Cache Read Miss Rate
// description: Percentage of time L1 Texture Cache read access is a Miss
// type: Percentage
function TextureCacheMissRate()
{
    return TPU_TL1C_TOP_GM_REQUEST  * 100 / (4.0 * TPU_TL1C_TOP_REQUEST4_VALID_ADDRESS + 3.0 * TPU_TL1C_TOP_REQUEST3_VALID_ADDRESS + 2.0 * TPU_TL1C_TOP_REQUEST2_VALID_ADDRESS + TPU_TL1C_TOP_REQUEST1_VALID_ADDRESS);
}

// name: Texture Cache Write Miss Rate in Vertex Shader
// description: Percentage of time L1 Texture Cache write access is a Miss for Vertex Shader
// type: Percentage
function VSTextureCacheWriteMissRate()
{
    return PBE_L1_MISS_vtx * 100.0 / (PBE_L1_MISS_vtx + PBE_L1_HIT_vtx); 
}

// name: Texture Cache Write Miss Rate in Fragment Shader
// description: Percentage of time L1 Texture Cache write access is a Miss for Fragment Shader
// type: Percentage
function FSTextureCacheWriteMissRate()
{
    return PBE_L1_MISS_frg * 100.0 / (PBE_L1_MISS_frg + PBE_L1_HIT_frg); 
}

// name: Texture Cache Write Miss Rate
// description: Percentage of time L1 Texture Cache write access is a Miss
// type: Percentage
function TextureCacheWriteMissRate()
{
    return PBE_L1_MISS * 100.0 / (PBE_L1_MISS + PBE_L1_HIT); 
}

// name: VS Bytes Read From Main Memory
// description: Total bytes read from main memory in Vertex Shader
// type: Value
function VSBytesReadFromMainMemory()
{
     return 64.0 * ((GM_GMMU_PMEMBANK0_META_READS_vtx + GM_GMMU_PMEMBANK1_META_READS_vtx + GM_GMMU_PMEMBANK2_META_READS_vtx + GM_GMMU_PMEMBANK3_META_READS_vtx) + 
                   (GM_GMMU_PMEMBANK0_NON_META_READS_vtx + GM_GMMU_PMEMBANK1_NON_META_READS_vtx + GM_GMMU_PMEMBANK2_NON_META_READS_vtx + GM_GMMU_PMEMBANK3_NON_META_READS_vtx));
}

// name: FS Bytes Read From Main Memory
// description: Total bytes read from main memory in Fragment Shader
// type: Value
function FSBytesReadFromMainMemory()
{
     return 64.0 * ((GM_GMMU_PMEMBANK0_META_READS_frg + GM_GMMU_PMEMBANK1_META_READS_frg + GM_GMMU_PMEMBANK2_META_READS_frg + GM_GMMU_PMEMBANK3_META_READS_frg) + 
                   (GM_GMMU_PMEMBANK0_NON_META_READS_frg + GM_GMMU_PMEMBANK1_NON_META_READS_frg + GM_GMMU_PMEMBANK2_NON_META_READS_frg + GM_GMMU_PMEMBANK3_NON_META_READS_frg));
}

// name: Bytes Read From Main Memory
// description: Total bytes read from main memory
// type: Value
function BytesReadFromMainMemory()
{
     return 64.0 * ((GM_GMMU_PMEMBANK0_META_READS + GM_GMMU_PMEMBANK1_META_READS + GM_GMMU_PMEMBANK2_META_READS + GM_GMMU_PMEMBANK3_META_READS) + 
                   (GM_GMMU_PMEMBANK0_NON_META_READS + GM_GMMU_PMEMBANK1_NON_META_READS + GM_GMMU_PMEMBANK2_NON_META_READS + GM_GMMU_PMEMBANK3_NON_META_READS));
}

// name: Bytes Written To Main Memory in Vertex Shader
// description: Total bytes written to main memory in vertex shader
// type: Value
function VSBytesWrittenToMainMemory()
{
     return 64.0 * (GM_GMMU_PMEMBANK0_WRITES_vtx + GM_GMMU_PMEMBANK1_WRITES_vtx + GM_GMMU_PMEMBANK2_WRITES_vtx + GM_GMMU_PMEMBANK3_WRITES_vtx);
}

// name: Bytes Written To Main Memory in Fragment Shader
// description: Total bytes written to main memory in fragment shader
// type: Value
function FSBytesWrittenToMainMemory()
{
     return 64.0 * (GM_GMMU_PMEMBANK0_WRITES_frg + GM_GMMU_PMEMBANK1_WRITES_frg + GM_GMMU_PMEMBANK2_WRITES_frg + GM_GMMU_PMEMBANK3_WRITES_frg);
}

// name: Bytes Written To Main Memory
// description: Total bytes written to main memory
// type: Value
function BytesWrittenToMainMemory()
{
     return 64.0 * (GM_GMMU_PMEMBANK0_WRITES + GM_GMMU_PMEMBANK1_WRITES + GM_GMMU_PMEMBANK2_WRITES + GM_GMMU_PMEMBANK3_WRITES);
}

// name: VS Global Atomic Bytes Read
// description: Total global atomic bytes read in Vertex Shader
// type: Value
function VSTotalGlobalAABytesRead()
{
    return 64.0 * Math.max(GM_GL2C_ROUTER_REQUEST_AA_vtx - GM_GL2C_ROUTER_REQUEST_AA_NO_RTN_vtx, 0.0);
}

// name: FS Global Atomic Bytes Read
// description: Total global atomic bytes read in fragment shader
// type: Value
function FSTotalGlobalAABytesRead()
{
    return 64.0 * Math.max(GM_GL2C_ROUTER_REQUEST_AA_frg - GM_GL2C_ROUTER_REQUEST_AA_NO_RTN_frg, 0.0);
}

// name: Global Atomic Bytes Read
// description: Total global atomic bytes read
// type: Value
function TotalGlobalAABytesRead()
{
    return 64.0 * Math.max(GM_GL2C_ROUTER_REQUEST_AA - GM_GL2C_ROUTER_REQUEST_AA_NO_RTN, 0.0);
}

// name: VS Global Atomic Bytes Written
// description: Total global atomic bytes written in Vertex Shader
// type: Value
function VSTotalGlobalAABytesWritten()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_AA_vtx);
}

// name: FS Global Atomic Bytes Written
// description: Total global atomic bytes written in fragment shader
// type: Value
function FSTotalGlobalAABytesWritten()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_AA_frg);
}

// name: Global Atomic Bytes Written
// description: Total global atomic bytes written
// type: Value
function TotalGlobalAABytesWritten()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_AA);
}

// name: VS L2 Bytes Read
// description: Total L2 bytes read in Vertex Shader
// type: Value
function VSTotalL2BytesRead()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_RC_vtx + GM_GL2C_ROUTER_REQUEST_RTI_vtx + GM_GL2C_ROUTER_REQUEST_RC_META_vtx + GM_GL2C_ROUTER_REQUEST_PREFETCH_vtx) + VSTotalGlobalAABytesRead();
}

// name: FS L2 Bytes Read
// description: Total L2 bytes read in fragment shader
// type: Value
function FSTotalL2BytesRead()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_RC_frg + GM_GL2C_ROUTER_REQUEST_RTI_frg + GM_GL2C_ROUTER_REQUEST_RC_META_frg + GM_GL2C_ROUTER_REQUEST_PREFETCH_frg) + FSTotalGlobalAABytesRead();
}

// name: L2 Bytes Read
// description: Total L2 bytes read
// type: Value
function TotalL2BytesRead()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_RC + GM_GL2C_ROUTER_REQUEST_RTI + GM_GL2C_ROUTER_REQUEST_RC_META + GM_GL2C_ROUTER_REQUEST_PREFETCH) + TotalGlobalAABytesRead();
}

// name: VS L2 bytes written
// description: Total L2 Bytes Written in vertex shader
// type: Value
function VSTotalL2BytesWritten()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_WB_vtx + GM_GL2C_ROUTER_REQUEST_WB_META_vtx + GM_GL2C_ROUTER_REQUEST_WTI_vtx) + VSTotalGlobalAABytesWritten()
}

// name: FS L2 Bytes Written
// description: Total L2 bytes written in fragment shader
// type: Value
function FSTotalL2BytesWritten()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_WB_frg + GM_GL2C_ROUTER_REQUEST_WB_META_frg + GM_GL2C_ROUTER_REQUEST_WTI_frg) + FSTotalGlobalAABytesWritten()
}

// name: L2 Bytes Written
// description: Total L2 bytes written
// type: Value
function TotalL2BytesWritten()
{
    return 64.0 * (GM_GL2C_ROUTER_REQUEST_WB + GM_GL2C_ROUTER_REQUEST_WB_META + GM_GL2C_ROUTER_REQUEST_WTI) + TotalGlobalAABytesWritten()
}

// name: VS Total Texture L1 Bytes Read
// description: Total bytes read from texture L1 cache in vertex shader
// type: Value
function VSTotalBytesReadFromTextureL1Cache()
{
    return 16.0*(4.0 * TPU_TL1C_TOP_REQUEST4_VALID_ADDRESS_vtx + 3.0 * TPU_TL1C_TOP_REQUEST3_VALID_ADDRESS_vtx + 2.0 * TPU_TL1C_TOP_REQUEST2_VALID_ADDRESS_vtx + TPU_TL1C_TOP_REQUEST1_VALID_ADDRESS_vtx);
}

// name: FS Total Texture L1 Bytes Read
// description: Total bytes read from texture L1 cache in fragment shader
// type: Value
function FSTotalBytesReadFromTextureL1Cache()
{
    return 16.0*(4.0 * TPU_TL1C_TOP_REQUEST4_VALID_ADDRESS_frg + 3.0 * TPU_TL1C_TOP_REQUEST3_VALID_ADDRESS_frg + 2.0 * TPU_TL1C_TOP_REQUEST2_VALID_ADDRESS_frg + TPU_TL1C_TOP_REQUEST1_VALID_ADDRESS_frg);
}

// name: Texture L1 Bytes Read
// description: Total bytes read from texture L1 cache
// type: Value
function TotalBytesReadFromTextureL1Cache()
{
    return 16.0*(4.0 * TPU_TL1C_TOP_REQUEST4_VALID_ADDRESS + 3.0 * TPU_TL1C_TOP_REQUEST3_VALID_ADDRESS + 2.0 * TPU_TL1C_TOP_REQUEST2_VALID_ADDRESS + TPU_TL1C_TOP_REQUEST1_VALID_ADDRESS);
}

// name: VS Buffer L1 Bytes Read
// description: Total bytes read from buffer L1 cache in vertex shader
// type: Value
function VSTotalBytesReadFromBufferL1Cache()
{
    return USC0_DM_GLD_WORK_vtx * 16.0;
}

// name: FS Buffer L1 Bytes Read
// description: Total bytes read from buffer L1 cache in fragment shader
// type: Value
function FSTotalBytesReadFromBufferL1Cache()
{
    return USC0_DM_GLD_WORK_frg * 16.0;
}

// name: Buffer L1 Bytes Read
// description: Total bytes read from buffer L1 cache
// type: Value
function TotalBytesReadFromBufferL1Cache()
{
    return USC0_DM_GLD_WORK * 16.0;
}

// name: VS Buffer L1 Bytes Written
// description: Total bytes written to buffer L1 cache in vertex shader
// type: Value
function VSTotalBytesWrittenBufferL1Cache()
{
    return USC0_DM_GST_WORK_vtx * 16.0;
}

// name: FS Buffer L1 Bytes Written
// description: Total bytes written to buffer L1 cache in fragment shader
// type: Value
function FSTotalBytesWrittenBufferL1Cache()
{
    return USC0_DM_GST_WORK_frg * 16.0;
}

// name: Buffer L1 Bytes Written
// description: Total bytes written to buffer L1 cache
// type: Value
function TotalBytesWrittenBufferL1Cache()
{
    return USC0_DM_GST_WORK * 16.0;
}

// name: Predicated Texture Thread Writes
// description: Percentage thread predicated out due to divergent control flow or small primitives covering part of quad in the render target on texture writes
// type: Percentage
function PredicatedTextureWritePercentage()
{
    if (PBE_NUM_PIXELS + PBE_NUM_QUADS > 0)
    {
        return Math.max(100.0 * (1.0 - PBE_NUM_PIXELS / PBE_NUM_QUADS), 0.0);
    }
    return 0.0;
}

// name: Predicated Texture Thread Reads
// description: Percentage threads predicated out due to divergent control flow or small primitives covering part of quad in the render target on texture reads
// type: Percentage
function PredicatedTextureReadPercentage()
{
    if (TPU_EVENT_NUM_PIXELS + TPU_EVENT_NUM_QUADS > 0)
    {
        return Math.max(100.0 * (1.0 - TPU_EVENT_NUM_PIXELS / (4.0*TPU_EVENT_NUM_QUADS)), 0.0);
    }
    return 0.0;
}

// name: Samples Shaded Per Tile
// description: Samples shaded per tile
// type: Rate
function SamplesShadedPerTile()
{
    return 64.0 * FRG0_SAMPLES_ITB_POST_TS / FRG0_STAT_PF_VALID_TILES_PROCESSED;
}

// name: Samples Shaded Per Quad
// description: Samples shaded per quad
// type: Rate
function SamplesShadedPerQuad()
{
    return 64.0 * FRG0_SAMPLES_ITB_POST_TS / Math.max(4.0 * FRG0_STAT_ITB_QUADS_PROCESSED, 1.0);
}

// name: VS Predicated Out ALU Percentage
// description: Percentage issued ALU operations predicated out due to divergent control flow in the verex shader
// type: Percentage
function VSPredicatedALUPercentage()
{
    var instructionsIssued = 64.0 * (USC1_DPB_NUM_ISS_F16_vtx + USC1_DPB_NUM_ISS_F32_vtx + USC1_DPB_NUM_ISS_SCIB_vtx + USC1_DPB_NUM_ISS_IC_vtx);
    var instructionsExecuted = 16.0 * (USC0_DPB_NUM_THR_F16_OPS_vtx + USC0_DPB_NUM_THR_F32_OPS_vtx + USC0_DPB_NUM_THR_SCIB_OPS_vtx + USC0_DPB_NUM_THR_IC_OPS_vtx);

    if (instructionsIssued + instructionsExecuted > 0)
    {
        return Math.max(100.0 * (1.0 - instructionsExecuted / instructionsIssued), 0.0);
    }
    return 0.0;
}

// name: FS Predicated Out ALU Percentage
// description: Percentage issued ALU operations predicated out due to divergent control flow in the fragment shader
// type: Percentage
function FSPredicatedALUPercentage()
{
    var instructionsIssued = 64.0 * (USC1_DPB_NUM_ISS_F16_frg + USC1_DPB_NUM_ISS_F32_frg + USC1_DPB_NUM_ISS_SCIB_frg + USC1_DPB_NUM_ISS_IC_frg);
    var instructionsExecuted = 16.0 * (USC0_DPB_NUM_THR_F16_OPS_frg + USC0_DPB_NUM_THR_F32_OPS_frg + USC0_DPB_NUM_THR_SCIB_OPS_frg + USC0_DPB_NUM_THR_IC_OPS_frg);

    if (instructionsIssued + instructionsExecuted > 0)
    {
        return Math.max(100.0 * (1.0 - instructionsExecuted / instructionsIssued), 0.0);
    }
    return 0.0;
}

// name: Kernel Predicated Out ALU Percentage
// description: Percentage issued ALU operations predicated out due to divergent control flow in the compute shader
// type: Percentage
function CSPredicatedALUPercentage()
{
    var instructionsIssued = 64.0 * (USC1_DPB_NUM_ISS_F16_cmp + USC1_DPB_NUM_ISS_F32_cmp + USC1_DPB_NUM_ISS_SCIB_cmp + USC1_DPB_NUM_ISS_IC_cmp);
    var instructionsExecuted = 16.0 * (USC0_DPB_NUM_THR_F16_OPS_cmp + USC0_DPB_NUM_THR_F32_OPS_cmp + USC0_DPB_NUM_THR_SCIB_OPS_cmp + USC0_DPB_NUM_THR_IC_OPS_cmp);

    if (instructionsIssued + instructionsExecuted > 0)
    {
        return Math.max(100.0 * (1.0 - instructionsExecuted / instructionsIssued), 0.0);
    }
    return 0.0;
}

// name: Thread Group Bytes Read
// description: Total bytes read from thread group memory
// type: Value
function TotalBytesReadFromThreadGroupMemory()
{
    return 16.0 * USC0_DM_LLD_WORK;
}

// name: Thread Group Bytes Written
// description: Total bytes written to thread group memory
// type: Value
function TotalBytesWrittenThreadGroupMemory()
{
    return 16.0 * USC0_DM_LST_WORK;
}

// name: Compression Ratio of Texture Memory Written
// description: Ratio of compressed to uncomressed texture memory written
// type: Rate
function CompressionRatioTextureMemoryWritten()
{
    var cmpUncompressedDataBytes = 
        16 * CMP_FMT_10_10_COMPRESS_REQUESTS +
        16 * CMP_FMT_10_11_11_COMPRESS_REQUESTS +
         8 * CMP_FMT_10_COMPRESS_REQUESTS +
        32 * CMP_FMT_16_16_16_16_COMPRESS_REQUESTS +
        16 * CMP_FMT_16_16_COMPRESS_REQUESTS +         
         8 * Math.min(CMP_FMT_16_COMPRESS_REQUESTS, PBE_FMT_16) + 32 * Math.max(CMP_FMT_16_COMPRESS_REQUESTS - PBE_FMT_16, 0) + 
         8 * CMP_FMT_1_5_5_5_COMPRESS_REQUESTS +
        32 * CMP_FMT_24_8_COMPRESS_REQUESTS +
        16 * CMP_FMT_2_10_10_10_COMPRESS_REQUESTS +
        32 * CMP_FMT_32_32_32_32_COMPRESS_REQUESTS +
        32 * CMP_FMT_32_32_COMPRESS_REQUESTS +
        16 * Math.min(CMP_FMT_32_COMPRESS_REQUESTS, PBE_FMT_32) + 32 * Math.max(CMP_FMT_32_COMPRESS_REQUESTS - PBE_FMT_32, 0) +
         8 * CMP_FMT_4_4_4_4_COMPRESS_REQUESTS +
         8 * CMP_FMT_5_5_5_1_COMPRESS_REQUESTS +
         8 * CMP_FMT_5_6_5_COMPRESS_REQUESTS +
        16 * CMP_FMT_5_9_9_9_COMPRESS_REQUESTS +
        16 * CMP_FMT_8_8_8_8_COMPRESS_REQUESTS +
         8 * CMP_FMT_8_8_COMPRESS_REQUESTS +
         4 * Math.min(CMP_FMT_8_COMPRESS_REQUESTS, PBE_FMT_8) + 32 * Math.max(CMP_FMT_8_COMPRESS_REQUESTS - PBE_FMT_8, 0);


    var cmpCompressedDataBytes = 32 * (CMP_GM_32B_METADATA_REQUESTS + 2.0 * (CMP_GM_64B_REQUESTS + 2.0*CMP_GM_128B_REQUESTS));
    return cmpUncompressedDataBytes / Math.max(cmpCompressedDataBytes, 1);
}

// name: Compression Ratio of Texture Memory Read
// description: Ratio of compressed to uncomressed texture memory read
// type: Rate
function CompressionRatioTextureMemoryRead()
{
    return (DCMP_ZLS_COMPRESSED_REQUESTS + DCMP_TL1C_COMPRESSED_REQUESTS) / Math.max(DCMP_COMPRESSION_GM_REQUESTS, 1);
}

// name: VS Arithmetic Intensity
// description: ALU ops per byte of main memory traffic in vertex shader
// type: Rate
function VSArithmeticIntensity()
{
    return VSALUInstructions() / Math.max(1, VSBytesReadFromMainMemory() + VSBytesWrittenToMainMemory());
}

// name: FS Arithmetic Intensity
// description: ALU Time in nSec per byte of main memory transfer in fragment shader
// type: Rate
function FSArithmeticIntensity()
{
    return FSALUInstructions() / Math.max(1, FSBytesReadFromMainMemory() + FSBytesWrittenToMainMemory());
}

// name: CS Arithmetic Intensity
// description: ALU ops per byte of main memory traffic in compute shader
// type: Rate
function CSArithmeticIntensity()
{
    return CSALUInstructions() / Math.max(1, BytesReadFromMainMemory() + BytesWrittenToMainMemory());
}

// name: VS Main Memory Throughput
// description: Main memory throughput in GB/s in a vertex shader
// type: Rate
function VSMainMemoryThroughput()
{
    return (VSBytesReadFromMainMemory() + VSBytesWrittenToMainMemory()) / Math.max(1, (GBL_GPU_N_CLK_TIMER_vtx * 41.666));
}

// name: FS Main Memory Throughput
// description: Main memory throughput in GB/s in a fragment shader
// type: Rate
function FSMainMemoryThroughput()
{
    return (FSBytesReadFromMainMemory() + FSBytesWrittenToMainMemory()) / Math.max(1, (GBL_GPU_N_CLK_TIMER_frg * 41.666));
}

// name: Main Memory Throughput
// description: Main memory throughput in GB/s
// type: Rate
function MainMemoryThroughput()
{
    return (BytesReadFromMainMemory() + BytesWrittenToMainMemory()) / Math.max(1, (GBL_GPU_N_CLK_TIMER * 41.666));
}

// name: VS ALU Performance
// description: ALU performance in Giga Ops / Sec in vertex shader
// type: Rate
function VSALUPerformance()
{
    return VSALUInstructions() / Math.max(1, (GBL_GPU_N_CLK_TIMER_vtx * 41.666));
}

// name: FS ALU Performance
// description: ALU performance in Giga Ops / Sec in fragment shader
// type: Rate
function FSALUPerformance()
{
    return FSALUInstructions() / Math.max(1, (GBL_GPU_N_CLK_TIMER_frg * 41.666));
}

// name: CS ALU Performance
// description: ALU performance in Giga Ops / Sec in compute shader
// type: Rate
function CSALUPerformance()
{
    return CSALUInstructions() / Math.max(1, (GBL_GPU_N_CLK_TIMER_cmp * 41.666));
}

// name: Buffer Read Limiter
// description: Measures the time during which buffer loads are attempted to execute as a percentage of peak buffer load performance.
// type: Percentage
function BufferLoadLimiter()
{    
    return USC_L1C_GLD_LIMITER_norm / (4.0 * num_cores);
}  

// name: VS Buffer Read Limiter
// description: VS Buffer read limiter
// type: Percentage
function VertexBufferLoadLimiter()
{    
    return USC_L1C_GLD_LIMITER_norm_vtx / (4.0 * num_cores);
}

// name: FS Buffer Read Limiter
// description: FS Buffer read limiter
// type: Percentage
function FragmentBufferLoadLimiter()
{    
    return USC_L1C_GLD_LIMITER_norm_frg / (4.0 * num_cores);
}

// name: Buffer Write Limiter
// description: Measures the time during which buffer stores are attempted to execute as a percentage of peak buffer load performance.
// type: Percentage
function BufferStoreLimiter()
{    
    return USC_L1C_GST_LIMITER_norm / (2.0 * num_cores);
}

// name: VS Buffer Write Limiter
// description: VS Buffer write limiter
// type: Percentage
function VertexBufferStoreLimiter()
{    
    return USC_L1C_GST_LIMITER_norm_vtx / (2.0 * num_cores);
}

// name: FS Buffer Write Limiter
// description: FS Buffer write limiter
// type: Percentage
function FragmentBufferStoreLimiter()
{    
    return USC_L1C_GST_LIMITER_norm_frg / (2.0 * num_cores);
}

// name: Fragment Input Interpolation Limiter
// description: Measures the time during which fragment shader input interpolation work is attempted to execute as a percentage of peak input interpolation performance.
// type: Percentage
function FragmentInputInterpolationLimiter()
{    
    return USC1_ITR_LIMITER_norm / (4.0 * num_cores);
}

// name: GPU Last Level Cache Limiter
// description: Measures the time during which GPU’s last level cache is attempting to service read and write requests as a percentage of cache’s peak performance.
// type: Percentage
function L2CacheLimiter()
{
    return (GM_GL2C_ROUTER_REQUEST_norm + GM_GL2C_ROUTER_GL2C_STALL_norm) / 4.0;
}

// name: GPU Last Level Cache Limiter Miss Rate
// description: Percentage of times GPU’s last level cache lookups are misses
// type: Percentage
function L2CacheMissRate()
{
    return 100.0 * GM_GL2C_TAG_LOOKUP_MISS / Math.max(GM_GL2C_ROUTER_REQUEST, 1.0);
}

// name: Vertex Occupancy
// description: Vertex occupancy
// type: Percentage
function VertexOccupancy()
{
    return USC1_VDM_SGID_COUNT_norm / (MAX_SGID_PER_USC * num_cores);
}

// name: Fragment Occupancy
// description: Fragment occupancy
// type: Percentage
function FragmentOccupancy()
{
    return USC1_PDM_SGID_COUNT_norm / (MAX_SGID_PER_USC * num_cores);
}

// name: Compute Occupancy
// description: Compute occupancy
// type: Percentage
function ComputeOccupancy()
{
    return USC1_CDM_SGID_COUNT_norm / (MAX_SGID_PER_USC * num_cores);
}

// name: GPU Read Bandwidth
// description: Measures how much memory, in gigabytes per second, are read by the GPU from a memory external to the GPU (potentially main memory).
// type: Rate
function GPUReadBandwidth()
{    
    return 64 * GM_GL2C_GL2C_MMU_REQUEST_RD / Math.max(1, (GBL_GPU_N_CLK_TIMER * 41.666));
}   

// name: GPU Write Bandwidth
// description: Measures how much memory, in gigabytes per second, are written by the GPU to a memory external to the GPU (potentially main memory).
// type: Rate
function GPUWriteBandwidth()
{    
    return 64 * Math.max(GM_GL2C_GL2C_MMU_REQUEST - GM_GL2C_GL2C_MMU_REQUEST_RD, 0.0) / Math.max(1, (GBL_GPU_N_CLK_TIMER * 41.666));
}   

// name: ALU Utilization
// description: ALU utilization
// type: Percentage
function ALUUtilization()
{
    return USC0_DPIL0_DPB_INSTR_WORK_norm / (2 * num_cores);
}

// name: F32 Utilization
// description: F32 utilization
// type: Percentage
function F32Utilization()
{
    return ((NUM_THREADS_PER_CLIQUE / 2) * USC1_DPB_NUM_ISS_F32_norm * 4) / (64 * num_cores);
}   

// name: F16 Utilization
// description: F16 utilization
// type: Percentage
function F16Utilization()
{
    return ((NUM_THREADS_PER_CLIQUE / 2) * USC1_DPB_NUM_ISS_F16_norm * 4) / (128 * num_cores);
}

// name: IC Utilization
// description: IC utilization
// type: Percentage
function ICUtilization()
{
    return ((NUM_THREADS_PER_CLIQUE / 2) * USC1_DPB_NUM_ISS_IC_norm * 4) / (32 * num_cores);
}

// name: SCIB Utilization
// description: SCIB utilization
// type: Percentage
function SCIBUtilization()
{
    return ((NUM_THREADS_PER_CLIQUE / 2) * USC1_DPB_NUM_ISS_SCIB_norm * 4) / (128 * num_cores);    
}

// name: Texture Sample Utilization
// description: Texture sample utilization
// type: Percentage
function TextureSamplesUtilization()
{
    return TPU_EVENT_USC_TSE_WORK_norm / (2.0 * num_cores);    
}

// name: Texture Write Utilization
// description: Texture write utilization
// type: Percentage
function TextureWritesUtilization()
{
    return PBE_USC_PBE_DATA_WORK_norm / (1.0 * num_cores);
}

// name: Buffer Load Utilization
// description: Buffer load utilization
// type: Percentage
function BufferLoadUtilization()
{
    return USC_L1C_GLD_REQUEST_norm / (4 * num_cores);
}

// name: Buffer Store Utilization
// description: Buffer store utilization
// type: Percentage
function BufferStoreUtilization()
{
    return USC_L1C_GST_REQUEST_norm / (2 * num_cores);
}

// name: Threadgroup/Imageblock Load Utilization
// description: Threadgroup/Imageblock load utilization
// type: Percentage
function LocalLoadUtilization()
{
    return USC0_DM_LLD_WORK_norm / (4.0 * num_cores);
}   

// name: Threadgroup/Imageblock Store Utilization
// description: Threadgroup/Imageblock store utilization
// type: Percentage
function LocalStoreUtilization()
{
    return USC0_DM_LST_WORK_norm / (4.0 * num_cores);
} 

// name: Fragment Input Interpolation Utilization
// description: Fragment input interpolation utilization
// type: Percentage
function FragmentInputInterpolationUtilization()
{
    return USC0_TGM_ITR_WORK_norm / (4.0 * num_cores);
}

// name: GPU Last Level Cache Utilization
// description: GPU last level cache utilization
// type: Percentage
function L2CacheUtilization()
{    
    return GM_GL2C_ROUTER_REQUEST_norm / 4.0;
}

// name: Partial Renders count
// description: Count number of partial renders in the encoder
// type: Count
function PartialRenders()
{
    return SW_PARTIAL_RENDER_COUNT;
}

// name: Parameter Buffer Bytes Used
// description: Parameter Buffer Bytes Used
// type: Count
function ParameterBufferBytesUsed()
{
    return SW_PBUsed;
}

// name: Frag Ticks Count
// description: Frag Tick for limiters
// type: Value
function FRGTicks()
{    
    return FRG1_COUNT_CYCLES;
}

// name: Texture Cache Limiter
// description: Texture cache limiter
// type: Percentage
function TextureCacheLimiter()
{
    return Math.min((TPU_TL1C_TOP_REQUEST_norm + TPU_TL1C_TOP_STALL_norm) / (num_cores), 100.0);
}  

// name: Fragment Generator Primitive Utilization
// description: Fragment generator primitive processing utilization
// type: Percentage
function FragmentGeneratorPrimitiveUtilization()
{
    return (FRG0_PRIMS_PROCESSED_norm) / (0.25 * num_cores);
}  

// name: Fragment Rasterizer Utilization
// description: Fragment Rasterizer utilization
// type: Percentage
function FragmentRasterizerUtilization()
{
    var msaa = 2.0 * FRG0_SAMPLES_ITB_PRE_DS_frg / Math.max(FRG0_PIXELS_ITB_PRE_DS_frg, 1.0);
    if (msaa > 1.1)
    {
        return Math.min((FRG0_SAMPLES_ITB_PRE_DS_norm_frg) / (num_cores), 100.0);
    }
    return Math.min((2.0 * FRG0_SAMPLES_ITB_PRE_DS_norm_frg) / (num_cores), 100.0);
}

// name: Fragment Quad Processor Utilization
// description: Fragment quad processor utilization
// type: Percentage
function FragmentQuadProcessingUtilization()
{
    return Math.min((4.0 * FRG0_STAT_ITB_QUADS_PROCESSED_norm_frg) / (2.0 * num_cores), 100.0);
}  

// name: Pre Culling Primitive Block Utilization
// description: Pre Culling primitive block utilization
// type: Percentage
function PreCullPrimitiveBlockUtilization()
{
    return Math.min(GTP_GP_PERF_TA_PPP_PRIMITIVE_norm_vtx / (0.5 * num_gps), 100.0);
}

// name: Pre Culling Primitive Count
// description: Pre Culling primitive count
// type: Percentage
function PreCullPrimitiveCount()
{
    return GTP_GP_PERF_TA_PPP_PRIMITIVE_vtx;
}

// name: Post Clipping Culling Primitive Block Utilization
// description: Post Clipping Culling primitive block utilization
// type: Percentage
function PostClipCullPrimitiveBlockUtilization()
{
    return Math.min(GTP_CORE_PERF_TA_VCE_PRIM_OUTPUT_norm_vtx / (num_gps), 100.0);
}

// name: Primitive Tile Intersection Utilization
// description: Primitive tile intersection utilization
// type: Percentage
function PrimitiveTileIntersectionUtilization()
{
    return Math.min(GTP_CORE_PERF_TE_RG_PRIMITIVE_norm_vtx / (num_gps), 100.0);
}

// name: Tiler Utilization
// description: Tiling block utilization
// type: Percentage
function TilerUtilization()
{
    return Math.min(GTP_CORE_PERF_TE_RG_TILE_norm_vtx / (num_gps), 100.0);
}

// name: GPU to main memory limiter
// description: GPU to main memory limiter
// type: Percentage
function MainMemoryTrafficLimiter()
{
    return Math.min((GM_GL2C_GL2C_MMU_REQUEST_norm + GM_GL2C_GL2C_MMU_STALL_REQUEST_norm) / 4.0, 100.0);
}


// name: GPU to main memory bidirectional traffic in bytes
// description: GPU to main memory bidirectional traffic in bytes
// type: Value
function MainMemoryTraffic()
{
    return 64.0 * GM_GL2C_GL2C_MMU_REQUEST;
}

// name: VS Invocation Unit Utilization
// description: VS invocation unit utilization
// type: Percentage
function VSInvocationUtilization()
{
    return Math.min(GTP_GP_PERF_VDM_VS_INVOCATION_norm_vtx / (0.5 * num_gps), 100.0);
}

// name: Fragment Z Store Unit Utilization
// description: Fragment Z store unit utilization
// type: Percentage
function FragmentZStoreUtilization()
{
    return Math.min((FRG1_GM_REQ_ZLS_CMP_STORE_norm_frg) / num_cores, 100.0);
}  

// name: Fragment Z Store Unit Bytes Written
// description: Fragment Z store unit bytes written
// type: Value
function FragmentZStoreBytes()
{
    return FRG1_GM_REQ_ZLS_CMP_STORE * 32;
}  

// name: Fragment Generator Primitive Processed
// description: Fragment generator primitive processed
// type: Value
function FragmentGeneratorPrimitiveProcessed()
{
    return FRG0_PRIMS_PROCESSED;
}

// name: Fragment Quads Processed
// description: Fragment generated quads processed
// type: Value
function FragmentQuadsProcessed()
{
    return 4.0 * FRG0_STAT_ITB_QUADS_PROCESSED_frg;
}    

// name: Pre Culling Primitive Count
// description: Pre Culling primitive count
// type: Value
function PreCullPrimitiveCount()
{
    return GTP_GP_PERF_TA_PPP_PRIMITIVE_vtx;
}

// name: Fragment Bytes Written
// description: Fragment bytes written
// type: Value
function FragmentStoreBytes()
{
    return 4.0*(PBE_FMT_8BITS + 2.0*PBE_FMT_16BITS + 4.0*PBE_FMT_32BITS + 8.0*PBE_FMT_64BITS + 16.0*PBE_FMT_128BITS);
}  

// name: Primitive Tile Intersections
// description: Primitive tile intersections
// type: Value
function PrimitiveTileIntersections()
{
    return GTP_CORE_PERF_TE_RG_PRIMITIVE_vtx;
}

// name: Tiles Processed in Tiler
// description: Tiles processed by tiling block
// type: Value
function TilerUtilization()
{
    return GTP_CORE_PERF_TE_RG_TILE_vtx;
}

// name: Fragment Generator Tiles Processed
// description: Fragment Generator Tiles Processed
// type: Value
function FragmentGeneratorTilesProcessed()
{
    return FRG0_STAT_PF_VALID_TILES_PROCESSED;
}

// name: Texture Cache Read Misses
// description: Texture cache miss count
// type: Value
function TextureCacheMissCount()
{
    return TPU_TL1C_TOP_GM_REQUEST;
}

// name: Fragment Z Unit Bytes Read
// description: Fragment Z unit bytes read
// type: Value
function FragmentZLoadBytes()
{
    return FRG1_GM_REQ_ZLS_DCMP_FETCHES * 64;
}  

// name: Fragment Interpolation Instructions
// description: Fragment interpolation instructions
// type: Value
function FragmentInterpolationInstructions()
{
    return 4 * (USC0_TGM_ITR_WORK);
}  

// name: ALU FP32 Instructions Executed
// description: ALU FP32 Instructions executed
// type: Value
function ALUF32()
{
    return (USC0_DPB_NUM_THR_F32_OPS * 16);
}

// name: ALU FP16 Instructions Executed
// description: CS ALU FP16 Instructions executed
// type: Value
function ALUF16()
{
    return (USC0_DPB_NUM_THR_F16_OPS * 16);
}

// name: ALU 32-bit Integer and Conditional Instructions Executed
// description: ALU Select, Conditional, 32-bit Integer and Boolean Instructions executed
// type: Value
function ALUInt32AndCond()
{
    return (USC0_DPB_NUM_THR_SCIB_OPS * 16);
}

// name: ALU Integer and Complex Instructions Executed
// description: ALU Integer and Complex Instructions executed
// type: Value
function ALUIntAndComplex()
{
    return (USC0_DPB_NUM_THR_IC_OPS * 16);
}

// name: ALU FP32 Instructions Issued
// description: ALU FP32 Instructions issued
// type: Value
function ALUF32Issued()
{
    return (USC1_DPB_NUM_ISS_F32 * 64);
}

// name: ALU FP16 Instructions Issued
// description: CS ALU FP16 Instructions issued
// type: Value
function ALUF16Issued()
{
    return (USC1_DPB_NUM_ISS_F16 * 64);
}

// name: ALU 32-bit Integer and Conditional Instructions Issued
// description: ALU Select, Conditional, 32-bit Integer and Boolean Instructions issued
// type: Value
function ALUInt32AndCondIssued()
{
    return (USC1_DPB_NUM_ISS_SCIB * 64);
}

// name: ALU Integer and Complex Instructions Issued
// description: ALU Integer and Complex Instructions issued
// type: Value
function ALUIntAndComplexIssued()
{
    return (USC1_DPB_NUM_ISS_IC * 64);
}

// name: Fragment Generator Primitive Processed Per Tile
// description: Fragment generator primitive processed per tile
// type: Rate
function AveragePrimitiveProcessedPerTile()
{
    return FragmentGeneratorPrimitiveProcessed() / FragmentGeneratorTilesProcessed();
}
