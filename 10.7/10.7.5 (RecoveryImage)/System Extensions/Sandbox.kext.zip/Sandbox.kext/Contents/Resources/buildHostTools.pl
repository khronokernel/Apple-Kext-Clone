#!/usr/bin/perl
#
# Are we building using an SDK and therefore need host compiled tools?
#
use POSIX;

my @os_release = split ('\.', (POSIX::uname())[2]);

my $target_suffix = '-HostTools';

if (defined $ENV{SDKROOT} and $ENV{CONFIGURATION} =~ m/(Release|Debug)(-\w+)/ and $2 ne $target_suffix) {
	my $host_configuration = $1 . $target_suffix;

	printf "\n>>>>> Building Host Tools for \"%s\"\n\n", $host_configuration;

	if (0) {
		print "<***> Current Env\n";
		foreach $k (sort keys %ENV) {
			printf "\t%s = %s\n", $k, $ENV{$k};
		}
		print "<***>\n";
	}

	# *Caution* Some variables work when passed in the environment,
	# others need to be expliclity placed onto the xcodebuild command line.

	my %old_env = %ENV;
	my $new_env;

	# Copy some variables in.
	map { $new_env{$_} = $ENV{$_}; } qw(PATH DEVELOPER_DIR DEVELOPER_BIN_DIR XCODE_DEVELOPER_USR_PATH);

	$new_env{RC_ARCHS} = $ENV{NATIVE_ARCH_ACTUAL};

	my @args = qw(xcodebuild -target sandbox-exec -configuration);

	push @args, $host_configuration;

	# Force the use of per-configuration build directories
	push @args, '-UsePerConfigurationBuildLocations=YES';

	# Need both clean and build -- Xcode does not run scripts when doing a clean.
	push @args, qw(clean build);

	push @args, map { $_ .'='. $ENV{OBJROOT}; } qw(BUILD_DIR OBJROOT SYMROOT);

	# Some versions of xcodebuild don't always set the CONFIGURATION_BUILD_DIR as a result
	# of setting CONFIGURATION. This forces an override.
	push @args, 'CONFIGURATION_BUILD_DIR='. $ENV{OBJROOT} .'/HostTools' if ($os_release[0] >= 11);

	# The following magic will change the name of directory the compiled tools are placed in.
	push @args, 'CONFIGURATION=HostTools';

	print "<***> Running: ". join (' ', @args). "\n\n";
	%ENV = %new_env;

	my $rv = system (@args);

	if ($rv == 0) {
		print "\n\n<<<<< Done building Host Tools\n\n";
	} else {
		print "\n\n<<<<< **** Host Tools Build Failed ****\n\n";
		exit ($? >> 8);
     }
}
